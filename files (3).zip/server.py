#!/usr/bin/env python3
"""MChat backend. Stdlib only.  Run:  python3 server.py [port]

- HTTP API used by index.html (auth, profile, groups, history, reactions, pins, reports, uploads)
- WebSocket at /ws (real-time messages, typing, presence, reactions, pins, deletes, mentions)
"""
import base64, hashlib, hmac, json, os, re, secrets, socket, sqlite3, struct, sys, threading, time
from collections import deque
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

BASE = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("MCHAT_DB", os.path.join(BASE, "mchat.db"))
UPLOAD_DIR = os.path.join(BASE, "uploads")
PORT = int(sys.argv[1]) if len(sys.argv) > 1 else int(os.environ.get("PORT", 8000))

MAX_BODY = 8 * 1024 * 1024
MAX_UPLOAD = 100 * 1024 * 1024
MAX_AVATAR = 2 * 1024 * 1024
MAX_COVER = 4 * 1024 * 1024
MAX_MSG = 4096
MAX_WS_FRAME = 256 * 1024
MAX_GROUP_MEMBERS = 200
HISTORY_PAGE = 20
STORAGE_LIMIT = 1024 * 1024 * 1024
PBKDF2_ITER = 200_000
SESSION_TTL = 60 * 60 * 24 * 90
WS_IDLE_TIMEOUT = 120
WS_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
AUTO_DELETE_OPTIONS = (0, 1, 3, 12, 24, 48, 72, 120, 168, 720)

NICK_RE = re.compile(r"^[A-Za-zА-Яа-яЁё0-9_]{3,24}$")
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
UPLOAD_URL_RE = re.compile(r"^/uploads/[a-f0-9]{32}(\.[a-z0-9]{1,8})?$")
MENTION_RE = re.compile(r"@([A-Za-z0-9_]{2,32})")

MIME = {
    "jpg": "image/jpeg", "jpeg": "image/jpeg", "png": "image/png", "gif": "image/gif", "webp": "image/webp",
    "mp4": "video/mp4", "webm": "video/webm", "mp3": "audio/mpeg", "ogg": "audio/ogg", "wav": "audio/wav",
    "pdf": "application/pdf", "txt": "text/plain; charset=utf-8",
}
INLINE_TYPES = {"jpg", "jpeg", "png", "gif", "webp"}

# ---------------------------------------------------------------- database
db_lock = threading.RLock()
db = sqlite3.connect(DB_PATH, check_same_thread=False)
db.row_factory = sqlite3.Row
db.executescript("""
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE COLLATE NOCASE,
    email TEXT,
    email_verified INTEGER NOT NULL DEFAULT 0,
    email_code TEXT,
    email_code_exp INTEGER,
    pass_salt TEXT NOT NULL,
    pass_hash TEXT NOT NULL,
    avatar TEXT NOT NULL DEFAULT '',
    cover TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT '',
    auto_delete_hours INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL,
    created_at INTEGER NOT NULL, expires_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS blocks (
    blocker_id INTEGER NOT NULL, blocked_id INTEGER NOT NULL,
    PRIMARY KEY (blocker_id, blocked_id)
);
CREATE TABLE IF NOT EXISTS groups (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL, description TEXT NOT NULL DEFAULT '',
    avatar TEXT NOT NULL DEFAULT '', creator_id INTEGER NOT NULL,
    created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS group_members (
    group_id INTEGER NOT NULL, user_id INTEGER NOT NULL,
    role TEXT NOT NULL DEFAULT 'member', joined_at INTEGER NOT NULL,
    PRIMARY KEY (group_id, user_id)
);
CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_key TEXT NOT NULL,
    sender_id INTEGER NOT NULL,
    receiver_id INTEGER NOT NULL DEFAULT 0,
    group_id INTEGER NOT NULL DEFAULT 0,
    body TEXT NOT NULL DEFAULT '',
    file_url TEXT NOT NULL DEFAULT '',
    reply_to_id INTEGER NOT NULL DEFAULT 0,
    created INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_messages_chat ON messages(chat_key, id);
CREATE TABLE IF NOT EXISTS chat_state (
    user_id INTEGER NOT NULL, chat_key TEXT NOT NULL,
    pinned INTEGER NOT NULL DEFAULT 0, cleared_upto INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (user_id, chat_key)
);
CREATE TABLE IF NOT EXISTS chat_pins (
    chat_key TEXT PRIMARY KEY, message_id INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS reactions (
    message_id INTEGER NOT NULL, user_id INTEGER NOT NULL, emoji TEXT NOT NULL,
    PRIMARY KEY (message_id, user_id, emoji)
);
CREATE TABLE IF NOT EXISTS reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT, reporter_id INTEGER NOT NULL,
    reported_id INTEGER NOT NULL, message_id INTEGER NOT NULL DEFAULT 0,
    reason TEXT NOT NULL, created INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS uploads (
    id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
    url TEXT NOT NULL UNIQUE, size INTEGER NOT NULL, created INTEGER NOT NULL
);
""")
db.commit()
_cols = [r["name"] for r in db.execute("PRAGMA table_info(users)").fetchall()]
if "cover" not in _cols:
    db.execute("ALTER TABLE users ADD COLUMN cover TEXT NOT NULL DEFAULT ''")
    db.commit()


def q(sql, args=()):
    with db_lock:
        rows = db.execute(sql, args).fetchall()
        db.commit()
    return rows


def q1(sql, args=()):
    rows = q(sql, args)
    return rows[0] if rows else None


def ex(sql, args=()):
    with db_lock:
        cur = db.execute(sql, args)
        db.commit()
        return cur


# ---------------------------------------------------------------- helpers
def now():
    return int(time.time())


def iso(ts):
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(ts))


def hash_password(password, salt=None):
    salt = salt or secrets.token_hex(16)
    return salt, hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), PBKDF2_ITER).hex()


def verify_password(password, salt, expected):
    return hmac.compare_digest(hash_password(password, salt)[1], expected)


def sha(s):
    return hashlib.sha256(s.encode()).hexdigest()


def public_user(row, private=False):
    u = {"id": row["id"], "username": row["username"], "avatar": row["avatar"] or "",
         "cover": row["cover"] or "", "status": row["status"] or ""}
    if private:
        u.update({"email": row["email"] or "", "email_verified": bool(row["email_verified"]),
                  "auto_delete_hours": row["auto_delete_hours"], "is_admin": False})
    return u


def dm_key(a, b):
    a, b = int(a), int(b)
    return f"u:{min(a, b)}:{max(a, b)}"


def group_key(gid):
    return f"g:{int(gid)}"


def dm_peer(key, me):
    _, a, b = key.split(":")
    a, b = int(a), int(b)
    return b if a == me else a


def is_group_member(gid, uid):
    return q1("SELECT 1 FROM group_members WHERE group_id=? AND user_id=?", (gid, uid)) is not None


def group_member_ids(gid):
    return [r["user_id"] for r in q("SELECT user_id FROM group_members WHERE group_id=?", (gid,))]


def chat_has_access(key, uid):
    if key.startswith("g:"):
        return is_group_member(int(key[2:]), uid)
    _, a, b = key.split(":")
    return uid in (int(a), int(b))


def chat_participants(key):
    if key.startswith("g:"):
        return group_member_ids(int(key[2:]))
    _, a, b = key.split(":")
    return list({int(a), int(b)})


def is_blocked_between(a, b):
    return q1("SELECT 1 FROM blocks WHERE (blocker_id=? AND blocked_id=?) OR (blocker_id=? AND blocked_id=?)",
              (a, b, b, a)) is not None


def chat_state(uid, key):
    return q1("SELECT pinned, cleared_upto FROM chat_state WHERE user_id=? AND chat_key=?", (uid, key))


_MSG_SELECT = """
SELECT m.*, u.username AS sender_name, u.avatar AS sender_avatar,
       r.body AS reply_to_body, ru.username AS reply_to_name
FROM messages m
JOIN users u ON u.id = m.sender_id
LEFT JOIN messages r ON r.id = m.reply_to_id
LEFT JOIN users ru ON ru.id = r.sender_id
"""


def build_messages(rows, viewer=None):
    rows = list(rows)
    if not rows:
        return []
    ids = [r["id"] for r in rows]
    reactions = {}
    if viewer is not None:
        marks = ",".join("?" * len(ids))
        for r in q(f"SELECT message_id, emoji, COUNT(*) AS cnt, "
                   f"MAX(CASE WHEN user_id=? THEN 1 ELSE 0 END) AS mine "
                   f"FROM reactions WHERE message_id IN ({marks}) GROUP BY message_id, emoji "
                   f"ORDER BY MIN(rowid)", (viewer, *ids)):
            reactions.setdefault(r["message_id"], []).append(
                {"emoji": r["emoji"], "count": r["cnt"], "mine": bool(r["mine"])})
    out = []
    for r in rows:
        out.append({
            "id": r["id"], "sender_id": r["sender_id"], "receiver_id": r["receiver_id"],
            "group_id": r["group_id"], "body": r["body"], "file_url": r["file_url"],
            "reply_to_id": r["reply_to_id"], "reply_to_body": r["reply_to_body"] or "",
            "reply_to_name": r["reply_to_name"] or "", "sender_name": r["sender_name"],
            "sender_avatar": r["sender_avatar"] or "", "created_at": iso(r["created"]),
            "reactions": reactions.get(r["id"], []),
        })
    return out


def load_message(mid):
    rows = q(_MSG_SELECT + " WHERE m.id=?", (mid,))
    return rows[0] if rows else None


def online_ids():
    return set(uid for uid, conns in list(connections.items()) if conns)


# ---------------------------------------------------------------- websocket plumbing
connections = {}                 # user_id -> list[WSConn]
conn_lock = threading.Lock()


class WSConn:
    def __init__(self, sock, wfile):
        self.sock = sock
        self.wfile = wfile
        self.user_id = None
        self.lock = threading.Lock()
        self.alive = True
        self.rate = deque()

    def _write(self, data):
        if not self.alive:
            return
        try:
            with self.lock:
                self.wfile.write(data)
                self.wfile.flush()
        except Exception:
            self.alive = False

    def send_json(self, payload):
        raw = json.dumps(payload, ensure_ascii=False).encode()
        self._write(frame(0x1, raw))

    def close(self):
        self._write(frame(0x8, b""))
        self.alive = False


def frame(opcode, payload):
    head = bytes([0x80 | opcode])
    n = len(payload)
    if n < 126:
        head += bytes([n])
    elif n < 65536:
        head += bytes([126]) + struct.pack("!H", n)
    else:
        head += bytes([127]) + struct.pack("!Q", n)
    return head + payload


def read_exact(rfile, n):
    buf = b""
    while len(buf) < n:
        chunk = rfile.read(n - len(buf))
        if not chunk:
            raise EOFError
        buf += chunk
    return buf


def read_frame(rfile):
    b1, b2 = read_exact(rfile, 2)
    fin = bool(b1 & 0x80)
    opcode = b1 & 0x0F
    masked = bool(b2 & 0x80)
    length = b2 & 0x7F
    if length == 126:
        length = struct.unpack("!H", read_exact(rfile, 2))[0]
    elif length == 127:
        length = struct.unpack("!Q", read_exact(rfile, 8))[0]
    if length > MAX_WS_FRAME:
        raise ValueError("frame too big")
    mask = read_exact(rfile, 4) if masked else b""
    payload = read_exact(rfile, length)
    if masked:
        payload = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
    return fin, opcode, payload


def register_conn(conn):
    with conn_lock:
        was_online = bool(connections.get(conn.user_id))
        connections.setdefault(conn.user_id, []).append(conn)
    if not was_online:
        notify_presence(conn.user_id, True)


def unregister_conn(conn):
    with conn_lock:
        lst = connections.get(conn.user_id, [])
        if conn in lst:
            lst.remove(conn)
        gone = not lst
        if gone:
            connections.pop(conn.user_id, None)
    if gone:
        notify_presence(conn.user_id, False)


def contact_ids(uid):
    ids = set()
    for r in q("SELECT chat_key FROM messages WHERE chat_key LIKE ? OR chat_key LIKE ?",
               (f"u:{uid}:%", f"u:%:{uid}")):
        ids.add(dm_peer(r["chat_key"], uid))
    for r in q("SELECT gm2.user_id FROM group_members gm1 JOIN group_members gm2 "
               "ON gm1.group_id = gm2.group_id WHERE gm1.user_id=?", (uid,)):
        ids.add(r["user_id"])
    ids.discard(uid)
    return ids


def notify_presence(uid, online):
    for cid in contact_ids(uid):
        send_to_user(cid, {"type": "status", "user_id": uid, "online": online})


def send_to_user(uid, payload):
    with conn_lock:
        conns = list(connections.get(uid, []))
    for c in conns:
        c.send_json(payload)


def send_to_chat(key, payload):
    for uid in chat_participants(key):
        send_to_user(uid, payload)


# ---------------------------------------------------------------- websocket message handling
def ws_error(conn, text):
    conn.send_json({"type": "error", "error": text})


def rate_ok(conn):
    t = time.time()
    while conn.rate and t - conn.rate[0] > 10:
        conn.rate.popleft()
    if len(conn.rate) >= 30:
        return False
    conn.rate.append(t)
    return True


def handle_ws_payload(conn, data):
    kind = data.get("type")
    if kind == "ping":
        return conn.send_json({"type": "pong"})
    if not rate_ok(conn):
        return ws_error(conn, "Слишком часто, подождите немного")
    me = q1("SELECT * FROM users WHERE id=?", (conn.user_id,))
    if me is None:
        conn.close()
        return
    if kind == "typing":
        try:
            to = int(data.get("to"))
        except (TypeError, ValueError):
            return
        if to and not is_blocked_between(me["id"], to):
            send_to_user(to, {"type": "typing", "to": me["id"]})
        return
    if kind in (None, "message"):
        return handle_send_message(conn, me, data)
    ws_error(conn, "Неизвестное действие")


def handle_send_message(conn, me, data):
    if not me["email_verified"]:
        return ws_error(conn, "Подтвердите email, чтобы писать сообщения")
    body = str(data.get("body") or "")
    file_url = str(data.get("file_url") or "")
    if len(body) > MAX_MSG:
        return ws_error(conn, f"Максимум {MAX_MSG} символов")
    if file_url and (not UPLOAD_URL_RE.match(file_url)
                     or not q1("SELECT 1 FROM uploads WHERE url=? AND user_id=?", (file_url, me["id"]))):
        return ws_error(conn, "Некорректный файл")
    if not body.strip() and not file_url:
        return ws_error(conn, "Пустое сообщение")
    try:
        group_id = int(data.get("group_id") or 0)
        receiver_id = int(data.get("receiver_id") or 0)
        reply_to_id = int(data.get("reply_to_id") or 0)
    except (TypeError, ValueError):
        return ws_error(conn, "Некорректные данные")

    if group_id:
        if not is_group_member(group_id, me["id"]):
            return ws_error(conn, "Вы не участник этой группы")
        key = group_key(group_id)
        receiver_id = 0
    else:
        if not receiver_id or not q1("SELECT 1 FROM users WHERE id=?", (receiver_id,)):
            return ws_error(conn, "Пользователь не найден")
        if receiver_id != me["id"] and is_blocked_between(me["id"], receiver_id):
            return ws_error(conn, "Сообщение нельзя отправить этому пользователю")
        key = dm_key(me["id"], receiver_id)
        group_id = 0

    if reply_to_id:
        target = q1("SELECT chat_key FROM messages WHERE id=?", (reply_to_id,))
        if not target or target["chat_key"] != key:
            reply_to_id = 0

    cur = ex("INSERT INTO messages (chat_key, sender_id, receiver_id, group_id, body, file_url, reply_to_id, created) "
             "VALUES (?,?,?,?,?,?,?,?)",
             (key, me["id"], receiver_id, group_id, body, file_url, reply_to_id, now()))
    row = load_message(cur.lastrowid)
    msg = build_messages([row])[0]

    send_to_chat(key, msg)

    if group_id:
        mentioned_everyone = "@everyone" in body
        names = {m.lower() for m in MENTION_RE.findall(body)}
        targets = set()
        for r in q("SELECT u.id, u.username FROM group_members gm JOIN users u ON u.id = gm.user_id "
                   "WHERE gm.group_id=? AND gm.user_id != ?", (group_id, me["id"])):
            if mentioned_everyone or r["username"].lower() in names:
                targets.add(r["id"])
        for uid in targets:
            send_to_user(uid, {"type": "mention", "group_id": group_id, "from_id": me["id"],
                               "from_name": me["username"], "message_id": msg["id"],
                               "preview": body[:80], "everyone": mentioned_everyone})


def websocket_session(handler):
    key = handler.headers.get("Sec-WebSocket-Key", "")
    if not key:
        return handler.send_text(400, "Bad WebSocket request")
    accept = base64.b64encode(hashlib.sha1((key + WS_GUID).encode()).digest()).decode()
    handler.wfile.write((
        "HTTP/1.1 101 Switching Protocols\r\n"
        "Upgrade: websocket\r\nConnection: Upgrade\r\n"
        f"Sec-WebSocket-Accept: {accept}\r\n\r\n").encode())
    handler.wfile.flush()
    handler.close_connection = True
    handler.request.settimeout(WS_IDLE_TIMEOUT)

    conn = WSConn(handler.request, handler.wfile)
    registered = False
    try:
        # first frame must authenticate
        fin, op, payload = read_frame(handler.rfile)
        try:
            first = json.loads(payload.decode("utf-8", "replace"))
        except ValueError:
            first = {}
        token = str(first.get("token") or "") if first.get("type") == "auth" else ""
        row = None
        if token:
            row = q1("SELECT u.id FROM sessions s JOIN users u ON u.id=s.user_id "
                     "WHERE s.token_hash=? AND s.expires_at>?", (sha(token), now()))
        if not row:
            conn.send_json({"type": "auth_error"})
            return
        conn.user_id = row["id"]
        register_conn(conn)
        registered = True
        conn.send_json({"type": "auth_ok"})

        buf = b""
        while conn.alive:
            fin, op, payload = read_frame(handler.rfile)
            if op == 0x8:
                conn._write(frame(0x8, b""))
                break
            if op == 0x9:
                conn._write(frame(0xA, payload))
                continue
            if op == 0xA:
                continue
            buf += payload
            if fin:
                raw, buf = buf, b""
                try:
                    data = json.loads(raw.decode("utf-8"))
                except ValueError:
                    ws_error(conn, "Некорректный запрос")
                    continue
                if isinstance(data, dict):
                    handle_ws_payload(conn, data)
    except (EOFError, ConnectionError, socket.timeout, ValueError, OSError):
        pass
    finally:
        conn.alive = False
        if registered:
            unregister_conn(conn)


# ---------------------------------------------------------------- multipart upload
def parse_multipart(body, boundary):
    delim = b"--" + boundary
    result = {}
    for part in body.split(delim)[1:]:
        if part.startswith(b"--"):
            break
        if part.startswith(b"\r\n"):
            part = part[2:]
        if part.endswith(b"\r\n"):
            part = part[:-2]
        if b"\r\n\r\n" not in part:
            continue
        head, data = part.split(b"\r\n\r\n", 1)
        h = head.decode("utf-8", "replace")
        m = re.search(r'name="([^"]*)"', h)
        fn = re.search(r'filename="([^"]*)"', h)
        if m:
            result[m.group(1)] = {"filename": fn.group(1) if fn else None, "data": data}
    return result


def storage_used(uid):
    row = q1("SELECT COALESCE(SUM(size),0) AS s FROM uploads WHERE user_id=?", (uid,))
    return row["s"]


def drop_file_if_unused(url):
    if not url or q1("SELECT 1 FROM messages WHERE file_url=?", (url,)):
        return
    ex("DELETE FROM uploads WHERE url=?", (url,))
    path = os.path.join(UPLOAD_DIR, os.path.basename(url))
    try:
        os.remove(path)
    except OSError:
        pass


# ---------------------------------------------------------------- auto-delete worker
def auto_delete_loop():
    while True:
        time.sleep(60)
        try:
            for u in q("SELECT id, auto_delete_hours FROM users WHERE auto_delete_hours > 0"):
                cutoff = now() - u["auto_delete_hours"] * 3600
                for m in q("SELECT id, chat_key, file_url FROM messages WHERE sender_id=? AND created<?",
                           (u["id"], cutoff)):
                    delete_message_everywhere(m["id"], m["chat_key"], m["file_url"])
        except Exception as e:
            sys.stderr.write(f"auto-delete error: {e!r}\n")


def delete_message_everywhere(mid, key, file_url):
    ex("DELETE FROM reactions WHERE message_id=?", (mid,))
    pinned = q1("SELECT 1 FROM chat_pins WHERE chat_key=? AND message_id=?", (key, mid))
    ex("DELETE FROM messages WHERE id=?", (mid,))
    ex("UPDATE messages SET reply_to_id=0 WHERE reply_to_id=?", (mid,))
    if pinned:
        ex("DELETE FROM chat_pins WHERE chat_key=?", (key,))
    send_to_chat(key, {"type": "delete", "message_id": mid})
    if pinned:
        notify_pin_change(key, 0)
    drop_file_if_unused(file_url)


def notify_pin_change(key, message_id):
    for uid in chat_participants(key):
        if key.startswith("g:"):
            payload = {"type": "pin_change", "chat_type": "group", "chat_id": int(key[2:]), "message_id": message_id}
        else:
            payload = {"type": "pin_change", "chat_type": "user", "chat_id": dm_peer(key, uid), "message_id": message_id}
        send_to_user(uid, payload)


# ---------------------------------------------------------------- HTTP handler
class Handler(BaseHTTPRequestHandler):
    server_version = "MChat/2.0"

    def log_message(self, fmt, *args):
        sys.stderr.write("%s - %s\n" % (self.address_string(), fmt % args))

    # low-level responses
    def send_json(self, code, data):
        body = json.dumps(data, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def send_text(self, code, text):
        body = text.encode()
        self.send_response(code)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def send_bytes(self, code, data, ctype, extra=None):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("X-Content-Type-Options", "nosniff")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(data)

    def read_body(self, limit):
        length = int(self.headers.get("Content-Length") or 0)
        if length > limit:
            raise ValueError("Слишком большой запрос")
        return read_exact(self.rfile, length) if length else b""

    def read_json(self):
        raw = self.read_body(MAX_BODY)
        try:
            data = json.loads(raw or b"{}")
        except ValueError:
            raise ValueError("Некорректный JSON")
        if not isinstance(data, dict):
            raise ValueError("Некорректный запрос")
        return data

    def current_user(self):
        token = (self.headers.get("Authorization") or "").strip()
        if not token:
            return None, None
        th = sha(token)
        row = q1("SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id "
                 "WHERE s.token_hash=? AND s.expires_at>?", (th, now()))
        return (row, th) if row else (None, None)

    def require_user(self):
        user, th = self.current_user()
        if not user:
            self.send_text(401, "Нужно войти в аккаунт")
            return None, None
        return user, th

    # dispatch
    def do_GET(self):
        url = urlparse(self.path)
        path = url.path
        if path == "/ws" and self.headers.get("Upgrade", "").lower() == "websocket":
            return websocket_session(self)
        if path in ("/", "/index.html"):
            with open(os.path.join(BASE, "index.html"), "rb") as f:
                return self.send_bytes(200, f.read(), "text/html; charset=utf-8", {"Cache-Control": "no-cache"})
        if path.startswith("/uploads/"):
            return self.serve_upload(path)
        if path == "/manifest.json":
            return self.send_json(200, {"name": "MChat", "short_name": "MChat", "start_url": "/",
                                        "display": "standalone", "background_color": "#0a0f1c",
                                        "theme_color": "#0a0f1c"})
        if path.startswith("/api/"):
            try:
                return self.route_get(path, parse_qs(url.query))
            except Exception as e:
                sys.stderr.write(f"error: {e!r}\n")
                return self.send_text(500, "Внутренняя ошибка сервера")
        self.send_text(404, "Не найдено")

    def do_POST(self):
        return self._api_write()

    def do_PATCH(self):
        return self._api_write()

    def _api_write(self):
        path = urlparse(self.path).path
        if not path.startswith("/api/"):
            return self.send_text(404, "Не найдено")
        try:
            if path == "/api/upload":
                return self.route_upload()
            data = self.read_json()
            return self.route_write(self.command, path, data)
        except ValueError as e:
            return self.send_text(400, str(e))
        except Exception as e:
            sys.stderr.write(f"error: {e!r}\n")
            return self.send_text(500, "Внутренняя ошибка сервера")

    def serve_upload(self, path):
        name = path[len("/uploads/"):]
        if not re.match(r"^[a-f0-9]{32}(\.[a-z0-9]{1,8})?$", name):
            return self.send_text(404, "Не найдено")
        full = os.path.join(UPLOAD_DIR, name)
        if not os.path.isfile(full):
            return self.send_text(404, "Не найдено")
        ext = name.rsplit(".", 1)[1] if "." in name else ""
        with open(full, "rb") as f:
            data = f.read()
        if ext in INLINE_TYPES:
            return self.send_bytes(200, data, MIME[ext], {"Cache-Control": "public, max-age=31536000"})
        ctype = MIME.get(ext, "application/octet-stream")
        return self.send_bytes(200, data, ctype, {
            "Content-Disposition": "attachment; filename=\"" + name + "\"",
            "Cache-Control": "public, max-age=31536000"})

    # GET routes
    def route_get(self, path, q_):
        if path == "/api/me":
            me, _ = self.require_user()
            if me:
                self.send_json(200, public_user(me, private=True))
            return
        me, _ = self.require_user()
        if not me:
            return
        uid = me["id"]

        if path == "/api/user":
            if q_.get("username"):
                row = q1("SELECT * FROM users WHERE username=? COLLATE NOCASE", (q_["username"][0].strip(),))
            elif q_.get("id"):
                try:
                    row = q1("SELECT * FROM users WHERE id=?", (int(q_["id"][0]),))
                except ValueError:
                    return self.send_text(400, "Некорректный id")
            else:
                return self.send_text(400, "Укажите юзернейм")
            if not row:
                return self.send_text(404, "Пользователь не найден")
            info = public_user(row)
            info["online"] = row["id"] in online_ids()
            return self.send_json(200, info)

        if path == "/api/chats":
            return self.send_json(200, self.list_chats(uid))

        if path == "/api/history":
            try:
                if q_.get("group"):
                    gid = int(q_["group"][0])
                    if not is_group_member(gid, uid):
                        return self.send_text(403, "Нет доступа")
                    key = group_key(gid)
                else:
                    peer = int(q_["with"][0])
                    key = dm_key(uid, peer)
                before = int(q_.get("before_id", ["0"])[0] or 0)
            except (KeyError, ValueError):
                return self.send_text(400, "Некорректный запрос")
            st = chat_state(uid, key)
            cleared = st["cleared_upto"] if st else 0
            rows = q(_MSG_SELECT + " WHERE m.chat_key=? AND m.id>? AND (? = 0 OR m.id<?) "
                     "ORDER BY m.id DESC LIMIT ?", (key, cleared, before, before, HISTORY_PAGE))
            msgs = build_messages(list(reversed(rows)), viewer=uid)
            return self.send_json(200, msgs)

        if path == "/api/message/pinned":
            try:
                if q_.get("peer_type", ["user"])[0] == "group":
                    key = group_key(int(q_["peer_id"][0]))
                else:
                    key = dm_key(uid, int(q_["peer_id"][0]))
            except (KeyError, ValueError):
                return self.send_text(400, "Некорректный запрос")
            if not chat_has_access(key, uid):
                return self.send_text(403, "Нет доступа")
            pin = q1("SELECT message_id FROM chat_pins WHERE chat_key=?", (key,))
            if not pin:
                return self.send_json(200, {"pinned": None})
            row = load_message(pin["message_id"])
            if not row:
                return self.send_json(200, {"pinned": None})
            m = build_messages([row])[0]
            return self.send_json(200, {"pinned": {"id": m["id"], "sender_name": m["sender_name"], "body": m["body"]}})

        if path == "/api/group":
            try:
                gid = int(q_["id"][0])
            except (KeyError, ValueError):
                return self.send_text(400, "Некорректный id")
            if not is_group_member(gid, uid):
                return self.send_text(403, "Нет доступа")
            return self.send_json(200, self.group_view(gid))

        if path == "/api/blocks":
            rows = q("SELECT u.* FROM blocks b JOIN users u ON u.id=b.blocked_id WHERE b.blocker_id=? "
                     "ORDER BY u.username", (uid,))
            return self.send_json(200, [public_user(r) for r in rows])

        if path == "/api/sessions":
            th = self.current_user()[1]
            rows = q("SELECT token_hash, created_at FROM sessions WHERE user_id=? AND expires_at>? "
                     "ORDER BY created_at DESC", (uid, now()))
            return self.send_json(200, [{
                "token": r["token_hash"][:16],
                "is_current": r["token_hash"] == th,
                "created_at": time.strftime("%d.%m.%Y %H:%M", time.localtime(r["created_at"])),
            } for r in rows])

        if path == "/api/storage":
            used = storage_used(uid)
            return self.send_json(200, {"used": used, "limit": STORAGE_LIMIT,
                                        "percent": round(used * 100 / STORAGE_LIMIT, 2)})
        self.send_text(404, "Не найдено")

    # POST / PATCH routes
    def route_write(self, method, path, data):
        if path == "/api/register" and method == "POST":
            return self.register(data)
        if path == "/api/login" and method == "POST":
            return self.login(data)
        if path == "/api/logout" and method == "POST":
            _, th = self.current_user()
            if th:
                ex("DELETE FROM sessions WHERE token_hash=?", (th,))
            return self.send_json(200, {"ok": True})

        me, th = self.require_user()
        if not me:
            return
        uid = me["id"]
        routes = {
            ("PATCH", "/api/me"): lambda: self.update_me(me, data),
            ("POST", "/api/me/nick"): lambda: self.change_nick(me, data),
            ("POST", "/api/email/set"): lambda: self.set_email(me, data),
            ("POST", "/api/email/resend"): lambda: self.resend_email(me),
            ("POST", "/api/email/verify"): lambda: self.verify_email(me, data),
            ("POST", "/api/block"): lambda: self.block(uid, data, True),
            ("POST", "/api/unblock"): lambda: self.block(uid, data, False),
            ("POST", "/api/session/kill"): lambda: self.kill_session(uid, th, data),
            ("POST", "/api/chat/pin"): lambda: self.chat_pin(uid, data),
            ("POST", "/api/chat/clear"): lambda: self.chat_clear(uid, data),
            ("POST", "/api/message/pin"): lambda: self.message_pin(uid, data),
            ("POST", "/api/message/delete"): lambda: self.message_delete(uid, data),
            ("POST", "/api/reaction/add"): lambda: self.reaction(uid, data),
            ("POST", "/api/report"): lambda: self.report(uid, data),
            ("POST", "/api/group/create"): lambda: self.group_create(uid, data),
            ("POST", "/api/group/update"): lambda: self.group_update(uid, data),
            ("POST", "/api/group/add"): lambda: self.group_add(uid, data),
            ("POST", "/api/group/kick"): lambda: self.group_kick(uid, data),
        }
        handler = routes.get((method, path))
        if not handler:
            return self.send_text(404, "Не найдено")
        return handler()

    # ---- auth & profile
    def register(self, data):
        username = str(data.get("username", "")).strip()
        email = str(data.get("email", "")).strip()
        password = str(data.get("password", ""))
        avatar = str(data.get("avatar", "") or "")
        if not NICK_RE.match(username):
            return self.send_text(400, "Юзернейм: 3–24 символа, буквы, цифры или _")
        if not EMAIL_RE.match(email) or len(email) > 254:
            return self.send_text(400, "Неверный email")
        if len(password) < 8 or len(password) > 200:
            return self.send_text(400, "Пароль от 8 до 200 символов")
        if len(avatar) > MAX_AVATAR or (avatar and not avatar.startswith("data:image/")):
            return self.send_text(400, "Некорректная аватарка")
        if q1("SELECT 1 FROM users WHERE username=? COLLATE NOCASE", (username,)):
            return self.send_text(409, "Этот юзернейм уже занят")
        salt, h = hash_password(password)
        cur = ex("INSERT INTO users (username, email, pass_salt, pass_hash, avatar, created_at) VALUES (?,?,?,?,?,?)",
                 (username, email, salt, h, avatar, now()))
        user = q1("SELECT * FROM users WHERE id=?", (cur.lastrowid,))
        self.send_json(200, {"token": self.new_session(user["id"]), "user": public_user(user, private=True)})

    def new_session(self, uid):
        token = secrets.token_urlsafe(32)
        ex("INSERT INTO sessions (token_hash, user_id, created_at, expires_at) VALUES (?,?,?,?)",
           (sha(token), uid, now(), now() + SESSION_TTL))
        return token

    def login(self, data):
        username = str(data.get("username", "")).strip()
        password = str(data.get("password", ""))
        user = q1("SELECT * FROM users WHERE username=? COLLATE NOCASE", (username,))
        if not user:
            hash_password(password)
            return self.send_text(401, "Неверный юзернейм или пароль")
        if not verify_password(password, user["pass_salt"], user["pass_hash"]):
            return self.send_text(401, "Неверный юзернейм или пароль")
        self.send_json(200, {"token": self.new_session(user["id"]), "user": public_user(user, private=True)})

    def update_me(self, me, data):
        status = str(data.get("status", me["status"]) or "")[:140]
        avatar = str(data.get("avatar", me["avatar"]) or "")
        cover = str(data.get("cover", me["cover"]) or "")
        if len(avatar) > MAX_AVATAR or (avatar and not avatar.startswith("data:image/")):
            return self.send_text(400, "Некорректная аватарка")
        if len(cover) > MAX_COVER or (cover and not cover.startswith("data:image/")):
            return self.send_text(400, "Некорректная обложка")
        try:
            hours = int(data.get("auto_delete_hours", me["auto_delete_hours"]))
        except (TypeError, ValueError):
            return self.send_text(400, "Некорректное значение автоудаления")
        if hours not in AUTO_DELETE_OPTIONS:
            return self.send_text(400, "Некорректное значение автоудаления")
        ex("UPDATE users SET status=?, avatar=?, cover=?, auto_delete_hours=? WHERE id=?",
           (status, avatar, cover, hours, me["id"]))
        self.send_json(200, {"ok": True})

    def change_nick(self, me, data):
        nick = str(data.get("username", "")).strip()
        if not NICK_RE.match(nick):
            return self.send_text(400, "Юзернейм: 3–24 символа, буквы, цифры или _")
        if q1("SELECT 1 FROM users WHERE username=? COLLATE NOCASE AND id!=?", (nick, me["id"])):
            return self.send_text(409, "Этот юзернейм уже занят")
        ex("UPDATE users SET username=? WHERE id=?", (nick, me["id"]))
        self.send_json(200, {"ok": True})

    def set_email(self, me, data):
        email = str(data.get("email", "")).strip()
        if not EMAIL_RE.match(email):
            return self.send_text(400, "Неверный email")
        code = f"{secrets.randbelow(1_000_000):06d}"
        ex("UPDATE users SET email=?, email_verified=0, email_code=?, email_code_exp=? WHERE id=?",
           (email, sha(code), now() + 900, me["id"]))
        print(f"[email] код подтверждения для {email}: {code}  (SMTP не настроен)", flush=True)
        self.send_json(200, {"ok": True})

    def resend_email(self, me):
        if not me["email"]:
            return self.send_text(400, "Email не указан")
        code = f"{secrets.randbelow(1_000_000):06d}"
        ex("UPDATE users SET email_code=?, email_code_exp=? WHERE id=?", (sha(code), now() + 900, me["id"]))
        print(f"[email] код для {me['email']}: {code}", flush=True)
        self.send_json(200, {"ok": True})

    def verify_email(self, me, data):
        code = str(data.get("code", "")).strip()
        if not me["email_code"] or now() > (me["email_code_exp"] or 0):
            return self.send_text(400, "Код истёк, запросите новый")
        if not hmac.compare_digest(sha(code), me["email_code"]):
            return self.send_text(400, "Неверный код")
        ex("UPDATE users SET email_verified=1, email_code=NULL WHERE id=?", (me["id"],))
        self.send_json(200, {"ok": True})

    def block(self, uid, data, add):
        try:
            target = int(data.get("user_id"))
        except (TypeError, ValueError):
            return self.send_text(400, "Некорректный пользователь")
        if target == uid:
            return self.send_text(400, "Нельзя заблокировать себя")
        if add:
            ex("INSERT OR IGNORE INTO blocks (blocker_id, blocked_id) VALUES (?,?)", (uid, target))
        else:
            ex("DELETE FROM blocks WHERE blocker_id=? AND blocked_id=?", (uid, target))
        self.send_json(200, {"ok": True})

    def kill_session(self, uid, current_th, data):
        public_id = str(data.get("token", ""))
        ex("DELETE FROM sessions WHERE user_id=? AND substr(token_hash,1,16)=? AND token_hash!=?",
           (uid, public_id, current_th or ""))
        self.send_json(200, {"ok": True})

    # ---- chats
    def list_chats(self, uid):
        out = []
        dm_keys = {r["chat_key"] for r in q("SELECT DISTINCT chat_key FROM messages WHERE chat_key LIKE ? "
                                              "OR chat_key LIKE ?", (f"u:{uid}:%", f"u:%:{uid}"))}
        online = online_ids()
        for key in dm_keys:
            peer = dm_peer(key, uid)
            if peer == uid:
                continue
            u = q1("SELECT * FROM users WHERE id=?", (peer,))
            if not u:
                continue
            st = chat_state(uid, key)
            last = self.last_visible(key, st)
            out.append({
                "type": "user", "id": peer, "username": u["username"], "name": u["username"],
                "avatar": u["avatar"] or "", "cover": u["cover"] or "", "status": u["status"] or "",
                "online": peer in online, "pinned": bool(st and st["pinned"]),
                "lastMsg": last["body"] if last else "", "lastMsgTime": iso(last["created"]) if last else "",
            })
        for g in q("SELECT g.* FROM groups g JOIN group_members gm ON gm.group_id=g.id WHERE gm.user_id=?", (uid,)):
            key = group_key(g["id"])
            st = chat_state(uid, key)
            last = self.last_visible(key, st)
            out.append({
                "type": "group", "id": g["id"], "name": g["name"], "avatar": g["avatar"] or "",
                "description": g["description"], "pinned": bool(st and st["pinned"]),
                "lastMsg": (last["body"] or "📎 Файл") if last else "",
                "lastMsgTime": iso(last["created"]) if last else "",
            })
        return out

    def last_visible(self, key, st):
        cleared = st["cleared_upto"] if st else 0
        return q1("SELECT body, created, file_url FROM messages WHERE chat_key=? AND id>? ORDER BY id DESC LIMIT 1",
                  (key, cleared))

    def group_view(self, gid):
        g = q1("SELECT * FROM groups WHERE id=?", (gid,))
        members = q("SELECT u.* FROM group_members gm JOIN users u ON u.id=gm.user_id "
                    "WHERE gm.group_id=? ORDER BY gm.joined_at", (gid,))
        return {"id": g["id"], "name": g["name"], "description": g["description"], "avatar": g["avatar"],
                "creator_id": g["creator_id"], "members": [public_user(m) for m in members]}

    def chat_pin(self, uid, data):
        try:
            key = group_key(data["peer_id"]) if data.get("peer_type") == "group" else dm_key(uid, data["peer_id"])
        except (KeyError, TypeError, ValueError):
            return self.send_text(400, "Некорректный запрос")
        if not chat_has_access(key, uid):
            return self.send_text(403, "Нет доступа")
        pinned = 0 if data.get("unpin") else 1
        ex("INSERT INTO chat_state (user_id, chat_key, pinned) VALUES (?,?,?) "
           "ON CONFLICT(user_id, chat_key) DO UPDATE SET pinned=excluded.pinned", (uid, key, pinned))
        self.send_json(200, {"ok": True})

    def chat_clear(self, uid, data):
        try:
            key = group_key(data["peer_id"]) if data.get("peer_type") == "group" else dm_key(uid, data["peer_id"])
        except (KeyError, TypeError, ValueError):
            return self.send_text(400, "Некорректный запрос")
        if not chat_has_access(key, uid):
            return self.send_text(403, "Нет доступа")
        top = q1("SELECT COALESCE(MAX(id),0) AS m FROM messages WHERE chat_key=?", (key,))["m"]
        ex("INSERT INTO chat_state (user_id, chat_key, cleared_upto) VALUES (?,?,?) "
           "ON CONFLICT(user_id, chat_key) DO UPDATE SET cleared_upto=excluded.cleared_upto", (uid, key, top))
        self.send_json(200, {"ok": True})

    # ---- messages
    def message_for(self, data, uid):
        try:
            mid = int(data.get("message_id"))
        except (TypeError, ValueError):
            return None, self.send_text(400, "Некорректное сообщение")
        m = q1("SELECT * FROM messages WHERE id=?", (mid,))
        if not m or not chat_has_access(m["chat_key"], uid):
            return None, self.send_text(404, "Сообщение не найдено")
        return m, None

    def message_pin(self, uid, data):
        m, err = self.message_for(data, uid)
        if err:
            return
        if data.get("unpin"):
            ex("DELETE FROM chat_pins WHERE chat_key=?", (m["chat_key"],))
            notify_pin_change(m["chat_key"], 0)
        else:
            ex("INSERT INTO chat_pins (chat_key, message_id) VALUES (?,?) "
               "ON CONFLICT(chat_key) DO UPDATE SET message_id=excluded.message_id", (m["chat_key"], m["id"]))
            notify_pin_change(m["chat_key"], m["id"])
        self.send_json(200, {"ok": True})

    def message_delete(self, uid, data):
        m, err = self.message_for(data, uid)
        if err:
            return
        allowed = m["sender_id"] == uid
        if not allowed and m["group_id"]:
            owner = q1("SELECT creator_id FROM groups WHERE id=?", (m["group_id"],))
            allowed = bool(owner) and owner["creator_id"] == uid
        if not allowed:
            return self.send_text(403, "Нельзя удалить чужое сообщение")
        delete_message_everywhere(m["id"], m["chat_key"], m["file_url"])
        self.send_json(200, {"ok": True})

    def reaction(self, uid, data):
        m, err = self.message_for(data, uid)
        if err:
            return
        emoji = str(data.get("emoji", ""))
        if not emoji or len(emoji) > 16:
            return self.send_text(400, "Некорректная реакция")
        if data.get("remove"):
            cur = ex("DELETE FROM reactions WHERE message_id=? AND user_id=? AND emoji=?", (m["id"], uid, emoji))
            changed, remove = cur.rowcount, True
        else:
            cur = ex("INSERT OR IGNORE INTO reactions (message_id, user_id, emoji) VALUES (?,?,?)", (m["id"], uid, emoji))
            changed, remove = cur.rowcount, False
        if changed:
            send_to_chat(m["chat_key"], {"type": "reaction", "message_id": m["id"], "user_id": uid,
                                         "emoji": emoji, "remove": remove})
        self.send_json(200, {"ok": True})

    def report(self, uid, data):
        try:
            reported = int(data.get("reported_id"))
            mid = int(data.get("message_id") or 0)
        except (TypeError, ValueError):
            return self.send_text(400, "Некорректная жалоба")
        reason = str(data.get("reason", "")).strip()[:500]
        if not reason:
            return self.send_text(400, "Напиши причину")
        if not q1("SELECT 1 FROM users WHERE id=?", (reported,)):
            return self.send_text(404, "Пользователь не найден")
        ex("INSERT INTO reports (reporter_id, reported_id, message_id, reason, created) VALUES (?,?,?,?,?)",
           (uid, reported, mid, reason, now()))
        self.send_json(200, {"ok": True})

    # ---- uploads
    def route_upload(self):
        me, _ = self.require_user()
        if not me:
            return
        if not me["email_verified"]:
            return self.send_text(403, "Подтвердите email, чтобы отправлять файлы")
        ctype = self.headers.get("Content-Type", "")
        m = re.search(r'boundary="?([^";]+)"?', ctype)
        if not ctype.startswith("multipart/form-data") or not m:
            return self.send_text(400, "Ожидается multipart/form-data")
        try:
            body = self.read_body(MAX_UPLOAD + 1024 * 1024)
        except ValueError as e:
            return self.send_text(413, str(e))
        part = parse_multipart(body, m.group(1).encode()).get("file")
        if not part or not part["data"]:
            return self.send_text(400, "Файл не получен")
        size = len(part["data"])
        if size > MAX_UPLOAD:
            return self.send_text(413, "Файл больше 100 МБ")
        if storage_used(me["id"]) + size > STORAGE_LIMIT:
            return self.send_text(413, "Закончилось место в хранилище")
        ext = os.path.splitext(part["filename"] or "")[1].lower().lstrip(".")
        ext = re.sub(r"[^a-z0-9]", "", ext)[:8]
        name = secrets.token_hex(16) + (("." + ext) if ext else "")
        os.makedirs(UPLOAD_DIR, exist_ok=True)
        with open(os.path.join(UPLOAD_DIR, name), "wb") as f:
            f.write(part["data"])
        url = "/uploads/" + name
        ex("INSERT INTO uploads (user_id, url, size, created) VALUES (?,?,?,?)", (me["id"], url, size, now()))
        self.send_json(200, {"url": url})

    # ---- groups
    def group_create(self, uid, data):
        name = str(data.get("name", "")).strip()
        if not 1 <= len(name) <= 64:
            return self.send_text(400, "Название от 1 до 64 символов")
        raw = data.get("members") or []
        if not isinstance(raw, list):
            return self.send_text(400, "Некорректный список участников")
        members = set()
        for v in raw:
            try:
                members.add(int(v))
            except (TypeError, ValueError):
                pass
        members.discard(uid)
        if not members:
            return self.send_text(400, "Добавьте хотя бы одного участника")
        if len(members) + 1 > MAX_GROUP_MEMBERS:
            return self.send_text(400, "Слишком много участников")
        existing = [r["id"] for r in q("SELECT id FROM users WHERE id IN (%s)" % ",".join("?" * len(members)),
                                       tuple(members))]
        cur = ex("INSERT INTO groups (name, creator_id, created_at) VALUES (?,?,?)", (name, uid, now()))
        gid = cur.lastrowid
        ex("INSERT INTO group_members (group_id, user_id, role, joined_at) VALUES (?,?,?,?)", (gid, uid, "owner", now()))
        for mid in existing:
            ex("INSERT OR IGNORE INTO group_members (group_id, user_id, role, joined_at) VALUES (?,?,?,?)",
               (gid, mid, "member", now()))
        send_to_chat(group_key(gid), {"type": "group_update", "group_id": gid})
        self.send_json(200, {"ok": True, "id": gid})

    def _group_owner_check(self, uid, data):
        try:
            gid = int(data.get("group_id"))
        except (TypeError, ValueError):
            return None, self.send_text(400, "Некорректная группа")
        g = q1("SELECT * FROM groups WHERE id=?", (gid,))
        if not g:
            return None, self.send_text(404, "Группа не найдена")
        if g["creator_id"] != uid:
            return None, self.send_text(403, "Только владелец может это сделать")
        return g, None

    def group_update(self, uid, data):
        g, err = self._group_owner_check(uid, data)
        if err:
            return
        name = str(data.get("name", g["name"])).strip() or g["name"]
        if len(name) > 64:
            return self.send_text(400, "Название до 64 символов")
        description = str(data.get("description", g["description"]) or "")[:300]
        avatar = str(data.get("avatar", "") or "") or g["avatar"]
        if len(avatar) > MAX_AVATAR or not avatar.startswith("data:image/") and avatar != g["avatar"]:
            return self.send_text(400, "Некорректная аватарка")
        ex("UPDATE groups SET name=?, description=?, avatar=? WHERE id=?", (name, description, avatar, g["id"]))
        send_to_chat(group_key(g["id"]), {"type": "group_update", "group_id": g["id"]})
        self.send_json(200, {"ok": True})

    def group_add(self, uid, data):
        g, err = self._group_owner_check(uid, data)
        if err:
            return
        try:
            target = int(data.get("user_id"))
        except (TypeError, ValueError):
            return self.send_text(400, "Некорректный пользователь")
        if not q1("SELECT 1 FROM users WHERE id=?", (target,)):
            return self.send_text(404, "Пользователь не найден")
        if is_group_member(g["id"], target):
            return self.send_text(409, "Уже в группе")
        if len(group_member_ids(g["id"])) >= MAX_GROUP_MEMBERS:
            return self.send_text(400, "Группа заполнена")
        ex("INSERT INTO group_members (group_id, user_id, role, joined_at) VALUES (?,?,?,?)",
           (g["id"], target, "member", now()))
        send_to_chat(group_key(g["id"]), {"type": "group_update", "group_id": g["id"]})
        self.send_json(200, {"ok": True})

    def group_kick(self, uid, data):
        g, err = self._group_owner_check(uid, data)
        if err:
            return
        try:
            target = int(data.get("user_id"))
        except (TypeError, ValueError):
            return self.send_text(400, "Некорректный пользователь")
        if target == g["creator_id"]:
            return self.send_text(400, "Нельзя исключить владельца")
        if not is_group_member(g["id"], target):
            return self.send_text(404, "Пользователя нет в группе")
        ex("DELETE FROM group_members WHERE group_id=? AND user_id=?", (g["id"], target))
        send_to_user(target, {"type": "kicked", "group_id": g["id"]})
        send_to_chat(group_key(g["id"]), {"type": "group_update", "group_id": g["id"]})
        self.send_json(200, {"ok": True})


if __name__ == "__main__":
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    threading.Thread(target=auto_delete_loop, daemon=True).start()
    ThreadingHTTPServer.daemon_threads = True
    print(f"MChat запущен: http://localhost:{PORT}  (база: {DB_PATH})", flush=True)
    ThreadingHTTPServer(("0.0.0.0", PORT), Handler).serve_forever()
